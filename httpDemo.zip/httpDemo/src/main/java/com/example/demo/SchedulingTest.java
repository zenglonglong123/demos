package com.example.demo;

import com.example.demo.tools.HttpUtil;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class SchedulingTest {
    private  int i = 0;
    @Scheduled(fixedRate = 60*1000)
    void doSomethingWith(){
        String u1 = "https://blog.csdn.net/zeng_ll/article/details/80217788";

        HttpUtil.doGet(u1);

        i++;
        System.out.println(i);
    }

}
