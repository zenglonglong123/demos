package com.example.demo.tools;

import org.apache.http.Consts;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;

public class HttpUtil {
    //创建日志
    private static final Logger logger = LoggerFactory.getLogger(HttpUtil.class);

    public static String doGet(String url){
        String body = "";
        HttpClient httpClient = HttpClientBuilder.create().build();
        HttpGet httpGet = new HttpGet(url);
        try {
            HttpResponse httpResponse = httpClient.execute(httpGet);
            HttpEntity httpEntity = httpResponse.getEntity();
            body = EntityUtils.toString(httpEntity, Consts.UTF_8);
            //释放连接
            httpGet.releaseConnection();
        } catch (IOException e) {
            e.printStackTrace();
            logger.error("request {} error", url, e);
        }
        return body;
    }
}
