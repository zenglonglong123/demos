package com.example.demo.producer_consumer;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingDeque;

/**
 * java多线程模拟生产者消费者问题
 */
public class ProducerConsumer {
    public static void main(String args[]){
        ProducerConsumer producerConsumer = new ProducerConsumer();

        Storage storage = producerConsumer.new Storage();
        ExecutorService service = Executors.newCachedThreadPool();
        Producer p = producerConsumer.new Producer("张三", storage);
        Producer p2 = producerConsumer.new Producer("李四", storage);
//        Consumer c = producerConsumer.new Consumer("王五", storage);
        Consumer c2 = producerConsumer.new Consumer("老刘", storage);
//        Consumer c3 = producerConsumer.new Consumer("老林", storage);
        service.submit(p);
        service.submit(p2);
//        service.submit(c);
        service.submit(c2);
//        service.submit(c3);
    }

    /**
     * 生产者
     */
    class Producer implements Runnable {
        private String name;
        private Storage storage = null;

        public Producer(String name, Storage storage) {
            this.name = name;
            this.storage = storage;
        }
        @Override
        public void run() {

            try {
                while (true) {
                    Product product = new Product((int) (Math.random() * 10000));  //产生0~9999的随机数
                    System.out.println(name + "准备生产(" + product.toString() + ").");
                    storage.push(product);
                    System.out.println(name + "已生产(" + product.toString() + ").");
                    storage.pop();
                    System.out.println("===============");
                    Thread.sleep(500);
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 消费者
     */
    class Consumer implements Runnable {
        private String name;
        private Storage storage = null;

        public Consumer(String name, Storage storage){
            this.name = name;
            this.storage = storage;
        }

        @Override
        public void run() {
            try {
                while (true) {
                    System.out.println(name + "准备消费产品.");
                    Product product = storage.pop();
                    System.out.println(name + "已消费(" + product.toString() + ").");
                    System.out.println("===============");
                    Thread.sleep(500);
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

        }

    }

    /**
     * 仓库
     */
    class Storage {
        BlockingQueue<Product> queues = new LinkedBlockingDeque<>();

        /**
         * 生产
         * @param product 产品
         * @throws InterruptedException
         */
        public void push(Product product) throws InterruptedException {
            queues.put(product);
        }

        /**
         * 消费
         * @return
         * @throws InterruptedException
         */
        public Product pop() throws InterruptedException {
            return queues.take();
        }
    }

    /**
     * 产品
     */
    class Product {
        private int id;

        public Product(int id){
            this.id = id;
        }

        public String toString(){
            return "产品： " + this.id;
        }
    }


}
